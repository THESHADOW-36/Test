var x = 123;

console.log(x)

// function reverse(num) {
//    for (var i = 0; i < num.length; i++) {
//       console.log(i)
//    }
// }

// console.log(reverse(x))